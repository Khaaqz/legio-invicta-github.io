import React from 'react';
import { motion } from 'motion/react';
import { Typewriter } from 'react-simple-typewriter';
import { GraduationCap, ArrowDown } from 'lucide-react';

export default function Hero() {
  const years = new Array(3).fill(2026); // Graduation year

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden py-24">
      {/* Background Effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gold/5 rounded-full blur-[150px] -translate-y-1/2 translate-x-1/4" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-navy/20 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/4" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
        className="relative z-10 container mx-auto px-6 text-center"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 text-gold text-sm font-display font-medium tracking-wide">
          <GraduationCap className="w-4 h-4" />
          <span>Angkatan 2023 - 2026</span>
        </div>

        <h1 className="text-5xl md:text-8xl font-display font-bold text-white mb-6 leading-tight tracking-tight">
          Selamat & <span className="text-gradient italic">Sukses</span> <br />
          Atas Kelulusan
        </h1>

        <div className="h-12 md:h-16 text-2xl md:text-4xl font-sans font-light text-white/80 mb-12">
          <Typewriter
            words={[
              'Langkah Awal Masa Depan Cerah',
              'Teruslah Bermimpi & Berkarya',
              'Kalian Adalah Kebanggaan Bangsa',
              'Mencapai Puncak Keberhasilan'
            ]}
            loop={true}
            cursor
            cursorStyle="_"
            typeSpeed={70}
            deleteSpeed={50}
            delaySpeed={2000}
          />
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          viewport={{ once: true }}
          className="text-white/50 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-16"
        >
          Perjalanan panjang telah dilalui dengan dedikasi. 
          Hari ini bukan akhir, melainkan gerbang menuju petualangan yang lebih besar.
        </motion.p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <button 
            onClick={() => document.getElementById('guestbook')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-primary"
          >
            TULIS UCAPAN
          </button>
          <button 
            onClick={() => document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-secondary"
          >
            LIHAT GALERI
          </button>
        </div>
      </motion.div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/30"
      >
        <ArrowDown className="w-8 h-8" />
      </motion.div>
      
      {/* Decorative Year Watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -z-10 select-none opacity-[0.03] text-[30vw] font-bold text-white italic">
        2026
      </div>
    </section>
  );
}
