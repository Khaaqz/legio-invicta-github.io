import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music, Volume2, VolumeX } from 'lucide-react';
import { useMusic } from '../lib/MusicContext';

export default function MusicPlayer() {
  const { isMuted, setIsMuted, isPausedByVideo } = useMusic();
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // We'll use a soft instrumental track from a public source
  const musicUrl = "https://github.com/Khaaqz/bahan/raw/refs/heads/main/Ini%20Abadi%20-%20Perunggu%20%20Lirik%20Lagu.mp3"; 

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsMuted(true);
      } else {
        audioRef.current.play();
        setIsMuted(false);
      }
      setIsPlaying(!isPlaying);
    }
  };

  useEffect(() => {
    // Sync with global mute state and auto-play
    if (audioRef.current) {
      audioRef.current.volume = 0.3;
      
      // Auto-play attempt (usually works after first interaction/opening)
      if (!isMuted && !isPausedByVideo) {
        audioRef.current.play().then(() => {
          setIsPlaying(true);
        }).catch(() => {
          // Fallback if browser blocks
          setIsPlaying(false);
        });
      }
    }
  }, [isMuted]);

  useEffect(() => {
    // Mute/Pause if video is playing in Gallery
    if (audioRef.current) {
      if (isPausedByVideo) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else if (!isMuted) {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  }, [isPausedByVideo]);

  return (
    <div className="fixed bottom-8 left-8 z-[90]">
      <audio ref={audioRef} src={musicUrl} loop />
      
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={togglePlay}
        className="relative group p-4 glass rounded-full text-gold flex items-center justify-center shadow-xl overflow-hidden"
      >
        <div className="absolute inset-0 bg-gold/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        
        {isPlaying ? (
          <Volume2 className="w-6 h-6 animate-pulse" />
        ) : (
          <VolumeX className="w-6 h-6 opacity-60" />
        )}

        <AnimatePresence>
          {isPlaying && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 'auto', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="overflow-hidden ml-2"
            >
              <div className="flex gap-1 items-center h-4 pr-1">
                {[1, 2, 3, 4].map(i => (
                  <motion.div
                    key={i}
                    animate={{ height: [4, 12, 4] }}
                    transition={{ 
                      repeat: Infinity, 
                      duration: 0.5 + Math.random(),
                      delay: i * 0.1
                    }}
                    className="w-0.5 bg-gold rounded-full"
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
}
