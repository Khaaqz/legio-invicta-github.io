import React, { useState, useEffect } from 'react';
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  serverTimestamp 
} from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, MessageSquare, Filter, X } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { CLASS_OPTIONS, Message, OperationType, FirestoreErrorInfo } from '../types';
import { cn } from '../lib/utils';

export default function Guestbook() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [name, setName] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [content, setContent] = useState('');
  const [selectedClass, setSelectedClass] = useState(CLASS_OPTIONS[0]);
  const [filterClass, setFilterClass] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'messages'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      setMessages(msgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'messages');
    });

    return () => unsubscribe();
  }, []);

  const handleFirestoreError = (error: unknown, operationType: OperationType, path: string | null) => {
    const errInfo: FirestoreErrorInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
      },
      operationType,
      path
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    // In a real app we might show a toast here
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || (!isAnonymous && !name.trim())) return;

    setLoading(true);
    try {
      await addDoc(collection(db, 'messages'), {
        name: isAnonymous ? 'Anonim' : name,
        class: selectedClass,
        content,
        createdAt: serverTimestamp()
      });
      if (!isAnonymous) setName('');
      setContent('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'messages');
    } finally {
      setLoading(false);
    }
  };

  const filteredMessages = filterClass 
    ? messages.filter(m => m.class === filterClass)
    : messages;

  return (
    <section className="py-24 bg-navy relative">
      <div className="container mx-auto px-6 max-w-5xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold text-white mb-4">
            Buku <span className="text-gradient italic">Kenangan</span>
          </h2>
          <p className="text-white/60">Tinggalkan pesan dan kesan untuk teman-teman seperjuangan.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass p-8 rounded-[32px]"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between px-1">
                  <label className="block text-xs font-bold uppercase tracking-widest text-amber-400">Nama Pengirim</label>
                  <label className="flex items-center gap-2 cursor-pointer group select-none">
                    <input 
                      type="checkbox" 
                      className="hidden peer"
                      checked={isAnonymous}
                      onChange={(e) => setIsAnonymous(e.target.checked)}
                    />
                    <div className="w-8 h-4 bg-white/10 rounded-full relative transition-all peer-checked:bg-amber-500">
                      <div className="absolute top-0.5 left-0.5 w-3 h-3 bg-white/40 rounded-full transition-all peer-checked:translate-x-4 peer-checked:bg-white" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-white/40 group-hover:text-amber-400 transition-colors">Anonim</span>
                  </label>
                </div>

                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <input
                    type="text"
                    value={isAnonymous ? 'Anonim' : name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={isAnonymous}
                    placeholder={isAnonymous ? "Mengirim sebagai Anonim" : "Masukkan nama Anda..."}
                    className={cn(
                      "w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:border-amber-400/50 transition-all",
                      isAnonymous && "opacity-50 cursor-not-allowed"
                    )}
                    required={!isAnonymous}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-amber-400 mb-3 ml-1">Pilih Kelas</label>
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-400/50 transition-all appearance-none cursor-pointer"
                >
                  {CLASS_OPTIONS.map(c => (
                    <option key={c} value={c} className="bg-navy">{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-amber-400 mb-3 ml-1">Pesan Ucapan</label>
                <div className="relative">
                  <MessageSquare className="absolute left-4 top-4 w-4 h-4 text-white/30" />
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Tuliskan ucapan atau kesan Anda..."
                    rows={4}
                    className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:border-amber-400/50 transition-all resize-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-5 rounded-2xl"
              >
                {loading ? "MENGIRIM..." : (
                  <div className="flex items-center justify-center gap-2">
                    <span>KIRIM PESAN</span>
                    <Send className="w-5 h-5" />
                  </div>
                )}
              </button>
            </form>
          </motion.div>

          {/* List Section */}
          <div className="flex flex-col h-full">
            <div className="flex flex-wrap gap-2 mb-8">
               <button 
                onClick={() => setFilterClass(null)}
                className={cn(
                    "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all",
                    !filterClass ? "bg-amber-400 text-navy" : "bg-white/5 border border-white/10 text-white/60"
                )}
               >
                SEMUA
               </button>
               {CLASS_OPTIONS.slice(0, 4).map(c => (
                 <button 
                  key={c}
                  onClick={() => setFilterClass(c)}
                  className={cn(
                      "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all",
                      filterClass === c ? "bg-amber-400 text-navy" : "bg-white/5 border border-white/10 text-white/60"
                  )}
                 >
                  {c}
                 </button>
               ))}
               <select
                  value={filterClass || ''}
                  onChange={(e) => setFilterClass(e.target.value || null)}
                  className="bg-white/5 border border-white/10 rounded-full py-2 px-4 text-[10px] text-white/60 font-bold uppercase focus:outline-none"
                >
                  <option value="" className="bg-navy">Lebih Banyak...</option>
                  {CLASS_OPTIONS.map(c => (
                    <option key={c} value={c} className="bg-navy">{c}</option>
                  ))}
                </select>
            </div>

            <div className="flex-1 space-y-4 max-h-[600px] overflow-y-auto pr-4 custom-scrollbar">
              <AnimatePresence mode="popLayout">
                {filteredMessages.length > 0 ? filteredMessages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="glass p-6 rounded-2xl border-white/5 relative group"
                  >
                    <div className="flex justify-between items-center mb-3">
                      <span className="font-bold text-sm text-amber-200">{msg.name}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] uppercase font-bold tracking-widest opacity-40">
                          {msg.class}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-white/70 leading-relaxed font-light">{msg.content}</p>
                    <div className="mt-4 flex items-center justify-between">
                        <div className="h-px flex-1 bg-white/5 mr-4" />
                        <span className="text-[10px] text-white/20 uppercase tracking-tighter">
                        {msg.createdAt?.toDate?.() ? new Date(msg.createdAt.toDate()).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                        }) : 'Baru saja'}
                        </span>
                    </div>
                  </motion.div>
                )) : (
                  <div className="text-center py-20 bg-white/[0.02] rounded-3xl border border-dashed border-white/10 text-white/20 text-sm">
                    Belum ada pesan...
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(212, 175, 55, 0.3);
          border-radius: 10px;
        }
      `}</style>
    </section>
  );
}
