import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Maximize2, X, ChevronLeft, ChevronRight, Play, Upload, Plus, Trash2, Camera, Video as VideoIcon } from 'lucide-react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { cn } from '../lib/utils';
import { useMusic } from '../lib/MusicContext';

interface AlbumItem {
  type: 'image' | 'video';
  url: string;
  thumbnail?: string;
  title: string;
}

interface Album {
  id: string;
  title: string;
  description: string;
  category: string;
  cover: string;
  items: AlbumItem[];
  createdAt: any;
}

const CATEGORIES = ["FOTO BERSAMA", "HIBURAN PEMADAM", "DJ MALAM"];

export default function Gallery() {
  const { setIsPausedByVideo } = useMusic();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [selectedAlbum, setSelectedAlbum] = useState<Album | null>(null);
  const [activeItemIndex, setActiveItemIndex] = useState(0);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  // Form State
  const [newAlbum, setNewAlbum] = useState({
    title: '',
    description: '',
    category: CATEGORIES[0],
    cover: '',
    items: [] as AlbumItem[]
  });

  useEffect(() => {
    const q = query(collection(db, 'albums'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Album));
      setAlbums(docs);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (selectedAlbum) {
      const currentItem = selectedAlbum.items[activeItemIndex];
      setIsPausedByVideo(currentItem?.type === 'video');
    } else {
      setIsPausedByVideo(false);
    }
  }, [selectedAlbum, activeItemIndex]);

  const handleNext = () => {
    if (!selectedAlbum) return;
    setActiveItemIndex((prev) => (prev + 1) % selectedAlbum.items.length);
  };

  const handlePrev = () => {
    if (!selectedAlbum) return;
    setActiveItemIndex((prev) => (prev - 1 + selectedAlbum.items.length) % selectedAlbum.items.length);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newItems: AlbumItem[] = [];
    for (let i = 0; i < files.length; i++) {
       const file = files[i];
       const type = file.type.startsWith('video/') ? 'video' : 'image';
       
       // In a real app, you'd upload to Firebase Storage here.
       // We'll use a local object URL for immediate feedback.
       const url = URL.createObjectURL(file);
       
       newItems.push({
         type,
         url,
         title: file.name,
         thumbnail: type === 'video' ? 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=400' : url
       });
    }

    setNewAlbum(prev => ({
      ...prev,
      items: [...prev.items, ...newItems],
      cover: prev.cover || newItems[0]?.url || ''
    }));
  };

  const handleCreateAlbum = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAlbum.title || newAlbum.items.length === 0) return;

    setIsUploading(true);
    try {
      // NOTE: Storing objectURLs in Firestore won't work across sessions/users.
      // For now, we'll store them, but warn that real storage is needed for persistence.
      await addDoc(collection(db, 'albums'), {
        ...newAlbum,
        createdAt: serverTimestamp()
      });
      setIsUploadOpen(false);
      setNewAlbum({ title: '', description: '', category: CATEGORIES[0], cover: '', items: [] });
    } catch (error) {
      console.error("Error creating album:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteAlbum = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Hapus album ini?')) return;
    await deleteDoc(doc(db, 'albums', id));
  };

  return (
    <section className="py-24 px-4 bg-navy/50 relative">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-amber-500 font-display font-bold tracking-[0.3em] text-xs uppercase mb-4 block">Arsip Album</span>
          <h2 className="text-4xl md:text-5xl font-display font-medium tracking-tight mb-8">Memori <span className="text-gradient">Tak Terlupakan</span></h2>
          <div className="w-12 h-1 bg-amber-500 mx-auto mb-8" />
          
          <button 
            onClick={() => setIsUploadOpen(true)}
            className="group flex items-center gap-3 px-6 py-3 bg-amber-500 hover:bg-amber-400 text-navy font-bold rounded-full transition-all shadow-[0_0_20px_rgba(245,158,11,0.2)] mx-auto"
          >
            <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
            <span>Tambah Album Baru</span>
          </button>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {albums.map((album) => (
              <motion.div
                key={album.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                onClick={() => {
                  setSelectedAlbum(album);
                  setActiveItemIndex(0);
                }}
                className="group cursor-pointer relative aspect-[3/4] overflow-hidden rounded-[32px] bg-white/5 border border-white/10 hover:border-amber-500/50 transition-all duration-500"
              >
                <img 
                  src={album.cover} 
                  alt={album.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/20 to-transparent flex flex-col justify-end p-8">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="px-3 py-1 bg-amber-500/20 text-amber-500 text-[10px] font-bold tracking-widest rounded-full uppercase border border-amber-500/30">
                      {album.items.length} Files
                    </span>
                  </div>
                  <h3 className="text-2xl font-display font-bold mb-2 group-hover:text-amber-400 transition-colors uppercase tracking-tight">
                    {album.title}
                  </h3>
                  <p className="text-sm text-white/40 font-sans line-clamp-2 italic leading-relaxed">
                    {album.description}
                  </p>
                  <div className="mt-6 flex items-center text-[10px] font-bold tracking-[0.2em] text-white/30 uppercase group-hover:text-amber-500 transition-colors">
                    Buka Album <ChevronRight className="w-4 h-4 ml-1" />
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Upload Modal */}
        <AnimatePresence>
          {isUploadOpen && (
            <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-navy/90 backdrop-blur-xl"
            >
              <div className="absolute inset-0" onClick={() => setIsUploadOpen(false)} />
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="relative w-full max-w-2xl bg-white/5 border border-white/10 rounded-[32px] p-8 md:p-12 shadow-2xl overflow-hidden backdrop-blur-2xl"
              >
                <h3 className="text-2xl font-display font-bold mb-8 flex items-center gap-3">
                  <Upload className="w-6 h-6 text-amber-500" />
                  BUAT ALBUM BARU
                </h3>

                <form onSubmit={handleCreateAlbum} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-2">Judul Album</label>
                       <input 
                         type="text" 
                         required
                         value={newAlbum.title}
                         onChange={e => setNewAlbum({...newAlbum, title: e.target.value})}
                         className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-amber-500/50 transition-all"
                         placeholder="e.g. Wisuda 2024"
                       />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-2">Kategori</label>
                       <select 
                         value={newAlbum.category}
                         onChange={e => setNewAlbum({...newAlbum, category: e.target.value})}
                         className="w-full bg-navy border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-amber-500/50 transition-all appearance-none"
                       >
                         {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                       </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-2">Deskripsi Singkat</label>
                    <textarea 
                      value={newAlbum.description}
                      onChange={e => setNewAlbum({...newAlbum, description: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-amber-500/50 transition-all h-24 resize-none"
                      placeholder="Ceritakan sedikit tentang memori ini..."
                    />
                  </div>

                  <div className="space-y-4">
                     <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-2">Pilih File (Foto/Video)</label>
                     <div className="grid grid-cols-4 gap-4">
                        {newAlbum.items.map((item, idx) => (
                          <div key={idx} className="relative aspect-square rounded-xl overflow-hidden group">
                             <img src={item.thumbnail || item.url} className="w-full h-full object-cover" />
                             {item.type === 'video' && <Play className="absolute inset-0 m-auto w-6 h-6 fill-white text-white" />}
                             <button 
                               type="button"
                               onClick={() => setNewAlbum({...newAlbum, items: newAlbum.items.filter((_, i) => i !== idx)})}
                               className="absolute top-1 right-1 p-1 bg-red-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                             >
                               <X className="w-3 h-3" />
                             </button>
                          </div>
                        ))}
                        <label className="aspect-square flex flex-col items-center justify-center border-2 border-dashed border-white/10 rounded-xl hover:border-amber-500 hover:bg-amber-400/5 transition-all cursor-pointer">
                           <Plus className="w-6 h-6 text-amber-500 mb-2" />
                           <span className="text-[8px] font-bold uppercase tracking-widest opacity-40">Add Files</span>
                           <input type="file" multiple accept="image/*,video/*" onChange={handleFileChange} className="hidden" />
                        </label>
                     </div>
                  </div>

                  <div className="pt-6 flex gap-4">
                     <button 
                       type="button"
                       onClick={() => setIsUploadOpen(false)}
                       className="flex-1 px-8 py-4 bg-white/5 border border-white/10 rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-white/10 transition-all"
                     >
                       Batal
                     </button>
                     <button 
                       disabled={isUploading || !newAlbum.title || newAlbum.items.length === 0}
                       className="flex-1 px-8 py-4 bg-amber-500 text-navy rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-amber-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
                     >
                       {isUploading ? 'Sedang Memproses...' : 'Simpan Album'}
                     </button>
                  </div>
                  <p className="text-center text-[9px] text-white/30 italic">
                    Catatan: File yang ditambahkan dari komputer hanya akan tampil jika file tersebut diunggah ke hosting atau menggunakan Firebase Storage.
                  </p>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* View Modal */}
        <AnimatePresence>
          {selectedAlbum && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12"
            >
              <div 
                className="absolute inset-0 bg-navy/95 backdrop-blur-2xl"
                onClick={() => setSelectedAlbum(null)}
              />
              
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative w-full max-w-6xl aspect-video md:aspect-[16/9] bg-black rounded-[40px] overflow-hidden shadow-2xl flex flex-col md:flex-row border border-white/10"
              >
                {/* Close Button */}
                <button 
                  onClick={() => setSelectedAlbum(null)}
                  className="absolute top-8 right-8 z-30 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-all backdrop-blur-md border border-white/10"
                >
                  <X className="w-6 h-6" />
                </button>

                {/* Main Content Area */}
                <div className="flex-1 relative bg-black group/media overflow-hidden">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={activeItemIndex}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 1.05 }}
                      transition={{ duration: 0.4 }}
                      className="w-full h-full flex items-center justify-center"
                    >
                      {selectedAlbum.items[activeItemIndex].type === 'image' ? (
                        <img 
                          src={selectedAlbum.items[activeItemIndex].url}
                          className="w-full h-full object-contain"
                          alt="Preview"
                        />
                      ) : (
                        <iframe 
                          src={selectedAlbum.items[activeItemIndex].url.includes('youtube') 
                            ? `${selectedAlbum.items[activeItemIndex].url}?autoplay=1&rel=0&showinfo=0`
                            : selectedAlbum.items[activeItemIndex].url
                          }
                          className="w-full h-full"
                          allow="autoplay; encrypted-media"
                          allowFullScreen
                        />
                      )}
                    </motion.div>
                  </AnimatePresence>

                  {/* Navigation Arrows */}
                  <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-6 pointer-events-none">
                    <button 
                      onClick={(e) => { e.stopPropagation(); handlePrev(); }}
                      className="p-5 bg-black/40 hover:bg-amber-500 rounded-full text-white transition-all opacity-0 group-hover/media:opacity-100 pointer-events-auto backdrop-blur-sm border border-white/10"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleNext(); }}
                      className="p-5 bg-black/40 hover:bg-amber-500 rounded-full text-white transition-all opacity-0 group-hover/media:opacity-100 pointer-events-auto backdrop-blur-sm border border-white/10"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </div>
                </div>

                {/* Dashboard Sidebar */}
                <div className="w-full md:w-96 bg-white/5 p-10 flex flex-col border-l border-white/10 backdrop-blur-xl">
                  <div className="flex-1 overflow-y-auto no-scrollbar">
                    <div className="mb-10">
                      <span className="text-amber-500 text-[10px] font-bold tracking-[0.3em] uppercase mb-4 block">
                        Kategori: {selectedAlbum.category}
                      </span>
                      <h2 className="text-3xl font-display font-bold mb-4 tracking-tight leading-tight uppercase text-white/90">
                        {selectedAlbum.title}
                      </h2>
                      <p className="text-sm text-white/40 font-sans italic leading-relaxed">
                        {selectedAlbum.description}
                      </p>
                    </div>

                    {/* Thumbnail Grid */}
                    <div className="grid grid-cols-3 gap-3 mb-10">
                      {selectedAlbum.items.map((item, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveItemIndex(idx)}
                          className={cn(
                            "aspect-square rounded-xl overflow-hidden border-2 transition-all relative group/thumb",
                            activeItemIndex === idx 
                              ? "border-amber-500 scale-95 shadow-[0_0_15px_rgba(245,158,11,0.3)]" 
                              : "border-transparent opacity-30 hover:opacity-100"
                          )}
                        >
                          <img 
                            src={item.thumbnail || item.url} 
                            className="w-full h-full object-cover"
                            alt="Thumb"
                          />
                          {item.type === 'video' && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black/40 group-hover/thumb:bg-black/20 transition-colors">
                              <Play className="w-5 h-5 fill-white text-white" />
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Dynamic Footer */}
                  <div className="mt-8 pt-8 border-t border-white/10">
                    <div className="flex items-center justify-between text-[10px] font-bold tracking-widest text-white/40 uppercase mb-4">
                      <span>File {activeItemIndex + 1} of {selectedAlbum.items.length}</span>
                      <div className="flex gap-1.5">
                        {selectedAlbum.items.map((_, i) => (
                          <div 
                            key={i}
                            className={cn(
                              "h-1 rounded-full transition-all duration-300",
                              activeItemIndex === i ? "w-6 bg-amber-500" : "w-2 bg-white/10"
                            )}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-white/60">
                      {selectedAlbum.items[activeItemIndex].type === 'image' ? (
                        <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest font-bold">
                          <Camera className="w-3.5 h-3.5 text-blue-500" /> Photo Mode
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest font-bold">
                          <VideoIcon className="w-3.5 h-3.5 text-red-500 animate-pulse" /> Video Mode
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
