import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

interface OpeningProps {
  onOpen: () => void;
  key?: string;
}

export default function Opening({ onOpen }: OpeningProps) {
  const [isOpening, setIsOpening] = useState(false);

  const handleOpen = () => {
    setIsOpening(true);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#d4af37', '#ffffff', '#0a192f']
    });
    
    // Smooth transition
    setTimeout(() => {
      onOpen();
    }, 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 1, ease: "easeInOut" }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-navy overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gold/10 rounded-full blur-[120px]" />
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        className="relative z-10 text-center px-6"
      >
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ repeat: Infinity, duration: 4 }}
          className="mb-8"
        >
          <Sparkles className="w-20 h-20 text-gold mx-auto mb-4 drop-shadow-[0_0_15px_rgba(212,175,55,0.5)]" />
        </motion.div>
        
        <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-4 tracking-tight leading-tight">
          HAPPY <span className="text-gradient italic">GRADUATION</span>
        </h1>
        
        <p className="text-white/60 text-lg md:text-xl font-sans mb-12 max-w-lg mx-auto">
          Momen bersejarah, lembaran baru penuh harapan. 
          Rayakan keberhasilanmu hari ini.
        </p>

        <button
          onClick={handleOpen}
          disabled={isOpening}
          className={cn(
            "btn-primary",
            isOpening && "opacity-0 scale-95"
          )}
        >
          <span className="relative z-10">Lihat</span>
        </button>
      </motion.div>

      {/* Floating Particles Simulation */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 100 + "%", 
              y: Math.random() * 100 + "%",
              opacity: 0 
            }}
            animate={{ 
              y: [null, "-100%"],
              opacity: [0, 1, 0]
            }}
            transition={{
              duration: Math.random() * 5 + 5,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
            className="absolute w-1 h-1 bg-white rounded-full"
          />
        ))}
      </div>
    </motion.div>
  );
}
