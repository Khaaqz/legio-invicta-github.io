import React from 'react';
import { GraduationCap, Instagram } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-24 border-t border-white/5 bg-black/20">
      <div className="container mx-auto px-6">
        <div className="flex flex-col items-center text-center">
          <div className="flex items-center gap-2 mb-6">
            <GraduationCap className="w-8 h-8 text-amber-500" />
            <span className="font-display font-bold text-2xl tracking-tighter">SMK Negeri 14 <span className="text-gradient">Garut</span></span>
          </div>
          
          <p className="text-white/40 max-w-lg mb-12 font-sans italic">
            "Terima kasih telah menjadi bagian dari keluarga besar kami. <br className="hidden md:block" />
            Selamat berjuang di langkah selanjutnya, alumni kebanggaan sekolah."
          </p>

          <div className="flex flex-wrap justify-center gap-6 md:gap-12 mb-16 px-4">
            <a 
              href="https://www.instagram.com/smkn14garut_official?igsh=MWR1YXUwZnV3NTB2NA==" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center gap-2 group"
            >
              <div className="p-3 bg-white/5 rounded-full border border-white/10 group-hover:border-gold group-hover:text-gold transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold tracking-widest text-white/30 uppercase group-hover:text-gold transition-colors">Sekolah</span>
            </a>

            <a 
              href="https://www.instagram.com/kesiswaan_smkn14?igsh=Nmp6dDliczJmYzRx" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center gap-2 group"
            >
              <div className="p-3 bg-white/5 rounded-full border border-white/10 group-hover:border-gold group-hover:text-gold transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold tracking-widest text-white/30 uppercase group-hover:text-gold transition-colors">Kesiswaan</span>
            </a>

            <a 
              href="https://www.instagram.com/legio_invicta2026?igsh=OTRqZHpsNmVjYzVv" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center gap-2 group"
            >
              <div className="p-3 bg-white/5 rounded-full border border-white/10 group-hover:border-gold group-hover:text-gold transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold tracking-widest text-white/30 uppercase group-hover:text-gold transition-colors">Angkatan</span>
            </a>
          </div>

          <div className="text-white/20 text-xs font-display tracking-widest uppercase">
            &copy; {currentYear} SMK NEGERI 14 GARUT. ALL RIGHTS RESERVED.
          </div>
        </div>
      </div>
    </footer>
  );
}
