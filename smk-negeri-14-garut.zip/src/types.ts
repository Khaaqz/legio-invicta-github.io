export interface Message {
  id?: string;
  name: string;
  class: string;
  content: string;
  createdAt: any;
}

export const CLASS_OPTIONS = [
  "XII DKV 1",
  "XII DKV 2",
  "XII DKV 3",
  "XII MPLB 1",
  "XII MPLB 2",
  "XII MPLB 3",
  "XII TKR 1",
  "XII TKR 2",
  "XII TPM",
  "XII TITL",
];

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}
