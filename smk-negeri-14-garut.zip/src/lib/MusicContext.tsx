import React, { createContext, useContext, useState } from 'react';

interface MusicContextType {
  isMuted: boolean;
  setIsMuted: (muted: boolean) => void;
  isPausedByVideo: boolean;
  setIsPausedByVideo: (paused: boolean) => void;
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export function MusicProvider({ children }: { children: React.ReactNode }) {
  const [isMuted, setIsMuted] = useState(false);
  const [isPausedByVideo, setIsPausedByVideo] = useState(false);

  return (
    <MusicContext.Provider value={{ isMuted, setIsMuted, isPausedByVideo, setIsPausedByVideo }}>
      {children}
    </MusicContext.Provider>
  );
}

export function useMusic() {
  const context = useContext(MusicContext);
  if (!context) throw new Error('useMusic must be used within MusicProvider');
  return context;
}
