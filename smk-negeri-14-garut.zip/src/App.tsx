import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Opening from './components/Opening';
import Hero from './components/Hero';
import Gallery from './components/Gallery';
import Guestbook from './components/Guestbook';
import MusicPlayer from './components/MusicPlayer';
import Footer from './components/Footer';
import { MusicProvider } from './lib/MusicContext';

export default function App() {
  const [hasOpened, setHasOpened] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="fixed inset-0 bg-navy flex items-center justify-center">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360] 
          }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="w-12 h-12 border-4 border-gold/20 border-t-gold rounded-full"
        />
      </div>
    );
  }

  return (
    <MusicProvider>
      <div className="min-h-screen bg-navy text-white selection:bg-gold/30 selection:text-gold relative overflow-x-hidden">
        <AnimatePresence mode="wait">
          {!hasOpened ? (
            <Opening key="opening" onOpen={() => setHasOpened(true)} />
          ) : (
            <motion.main
              key="main"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1 }}
              className="relative"
            >
              {/* Background Atmospheric Effects */}
              <div className="fixed inset-0 pointer-events-none -z-10">
                <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-900/20 blur-[120px] rounded-full" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-amber-500/10 blur-[120px] rounded-full" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-navy opacity-80" />
              </div>
              
              {/* Decorative Particles (Static-ish) */}
              <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
                 <div className="absolute top-20 left-40 w-1 h-1 bg-amber-400 rounded-full animate-pulse" />
                 <div className="absolute top-60 right-80 w-2 h-2 bg-white/40 rounded-full" />
                 <div className="absolute bottom-40 left-1/3 w-1.5 h-1.5 bg-amber-200/50 rounded-full" />
              </div>

              <MusicPlayer />
              
              <Hero />
              
              <section id="gallery" className="scroll-mt-20">
                <Gallery />
              </section>
              
              <section id="guestbook" className="scroll-mt-20">
                <Guestbook />
              </section>
              
              <Footer />

              {/* Custom Cursor/Follower Effect (Optional but Premium) */}
              <CursorOverlay />
            </motion.main>
          )}
        </AnimatePresence>
      </div>
    </MusicProvider>
  );
}

function CursorOverlay() {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 rounded-full border border-gold/30 pointer-events-none z-[200] hidden lg:block"
      animate={{ 
        x: position.x - 16, 
        y: position.y - 16,
        scale: [1, 1.2, 1] 
      }}
      transition={{ 
        type: 'spring', 
        damping: 30, 
        stiffness: 250, 
        mass: 0.5,
        scale: { repeat: Infinity, duration: 2 }
      }}
    />
  );
}
